<?php
//公共类
namespace app\admin\common;

//TP门面类
use think\Facade;
//TPResponse类
use think\Response;
//TPCache类
use think\facade\Cache;
//TP请求类
use think\facade\Request;
//TPDb类
use think\facade\Db;

class Common extends Facade
{

}
